package Klassen;public class GastVorhandenException {
}
