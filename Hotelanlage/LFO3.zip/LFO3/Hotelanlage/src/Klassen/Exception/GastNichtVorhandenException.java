package Klassen;public class GastNichtVorhandenException {
}
