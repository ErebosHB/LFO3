package Klassen;

import java.util.HashMap;
import java.util.Map;

public class GastDAO {
    Map<Integer, Gast> gastMap = new HashMap<>();


    public void insert(Gast gast){
        if (!gastMap.containsKey(gast.getGastNr())){
            gastMap.put(gast.getGastNr(),gast);
        }




    }
}
