public interface Fahrzeug {

    void fahren();
    void bremsen();
}
