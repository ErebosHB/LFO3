public interface Fluggeraet {
    void fliegen();

    void landen();
}
