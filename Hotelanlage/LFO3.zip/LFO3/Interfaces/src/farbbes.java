public abstract class farbbes {
    private String farbe;

    public farbbes(String farbe) {
    }

    public String getFarbe() {
        return farbe;
    }
}
